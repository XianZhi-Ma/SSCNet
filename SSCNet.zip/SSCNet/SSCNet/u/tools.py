import cv2
import torch
import math
import random
import numpy as np
from utils.config import cfg
from torch.nn import functional as F
# 将label和输出的特征图转化为相同尺寸
def msc_label_same(lbl, s1):
    lbl[lbl == 255] = 0
    label = F.interpolate(lbl, (s1[2], s1[3]))
    # 对图片起缩放作用 cv2.resize(img, (width, height), interpolation=cv2.INTER_NEAREST : 插值方式最近邻插值)
    # label = [cv2.resize(temp, (s1[3], s1[2]), interpolation=cv2.INTER_LINEAR) for temp in lbl[:]]
    # 转化成torch
    label = torch.from_numpy(np.array(label))
    return label

# 调整学习速率
def adjust_learning_rate(optimizer, iter, lr):
    """
    Change learning rate in optimizer.
    Return learning rate of resnet part for tensorboardX
    """
    if not cfg.TRAIN.IF_POLY_POLICY and iter % cfg.TRAIN.LR_DECAY_ITERS or iter == 0: return lr
    for param_group in optimizer.param_groups:
        if cfg.TRAIN.IF_POLY_POLICY and iter != 0:
            s = math.pow((1 - iter / cfg.TRAIN.MAX_ITERS), cfg.TRAIN.POWER)
            t = round(param_group['lr'] / lr) # t = 1 or 10
            # assert (t == 1 or t == 10)
            if not(t == 1 or t == 10):
                print("\n\n Not 1 or 10 when iter = %d, t = %f \n\n" % (iter, param_group['lr'] / lr))
            param_group['lr'] = t * cfg.TRAIN.LEARNING_RATE * s
        elif iter % cfg.TRAIN.LR_DECAY_ITERS == 0 and iter != 0:
            param_group['lr'] = 0.1 * param_group['lr']

    if cfg.TRAIN.IF_POLY_POLICY:
        return cfg.TRAIN.LEARNING_RATE * s
    else:
        return 0.1 * lr